﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace imagelist
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int current = 0;
        private void Form1_Load(object sender, EventArgs e)
        {
            button1.ImageList = imageList1;
            button1.ImageIndex = 0;
            button2.ImageList = imageList1;
            button2.ImageIndex = 1;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            /*string path = Environment.CurrentDirectory + "/pictures/";
            List<string> list = new List<string>();
            list.Add("001.jpg");
            list.Add("002.jpg");
            list.Add("003.jpg");
            list.Add("004.jpg");
            list.Add("005.jpg");
            ImageList imglist = new ImageList();
            imglist.ImageSize = new Size(248, 248);
            imglist.ColorDepth = ColorDepth.Depth32Bit;
            foreach (string i in list)
                imglist.Images.Add(Image.FromFile(path + i));
            current--;
            if (current == -1)
                current = list.Count;
            button3.ImageList = imglist;
            button3.ImageIndex = current;*/
            var path = Environment.CurrentDirectory + "/pictures/";
            var list = new List<string>();
            list.Add("001.jpg");
            list.Add("002.jpg");
            list.Add("003.jpg");
            list.Add("004.jpg");
            list.Add("005.jpg");
            ImageList imglist = new ImageList();
            imglist.ImageSize = new Size(248, 248);
            imglist.ColorDepth = ColorDepth.Depth32Bit;
            foreach (var fileName in list)
                imglist.Images.Add(Image.FromFile(path + fileName));
            current--;
            if (current == -1)
                current = 5;
            button3.ImageList = imglist;
            button3.ImageIndex = current;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var path = Environment.CurrentDirectory + "/pictures/";
            var list = new List<string>();
            list.Add("001.jpg");
            list.Add("002.jpg");
            list.Add("003.jpg");
            list.Add("004.jpg");
            list.Add("005.jpg");
            ImageList imglist = new ImageList();
            imglist.ImageSize = new Size(248, 248);
            imglist.ColorDepth = ColorDepth.Depth32Bit;
            foreach (var fileName in list)
                imglist.Images.Add(Image.FromFile(path + fileName));
            current++;
            if (current == 5)
                current = 0;
            button3.ImageList = imglist;
            button3.ImageIndex = current;
        }
    }
}
