﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace s1101327_Assignment2_4
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }
        DataTable table = new DataTable();
        private void Form1_Load(object sender, EventArgs e)
        {

            table.Columns.Add("姓名");
            table.Columns.Add("國文");
            table.Columns.Add("英文");
            dataGridView1.DataSource = table;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string[,] student = {
                { "王一", "80", "55" },
                { "黃二", "45", "50" },
                { "張三", "60", "40" },
                { "李四", "90", "80" },
                { "陳五", "20", "70" } };
            table.Rows.Clear();

            int chinese_score = Convert.ToInt32(textBox1.Text);
            int english_score = Convert.ToInt32(textBox2.Text);
            int student_chinese, student_english;
            string[] name;

            for (int i = 0;i<student.GetLength(0);i++)
            {
                student_chinese = Convert.ToInt32(student[i, 1]);
                student_english = Convert.ToInt32(student[i, 2]);

                if (student_chinese >= chinese_score && student_english >= english_score)
                {
                    name = new string[student.GetLength(1)];
                    for(int i2 = 0;i2<student.GetLength(1);i2++)
                    {
                        name[i2] = student[i,i2];
                    }
                    table.Rows.Add(name);
                }
                
            }
           
        }
    }
}
