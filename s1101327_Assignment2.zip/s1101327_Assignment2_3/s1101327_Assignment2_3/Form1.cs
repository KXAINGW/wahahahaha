﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace s1101327_Assignment2_3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string[,] student = { 
                { "王一", "80", "55" }, 
                { "黃二", "45", "50" }, 
                { "張三", "60", "40" }, 
                { "李四", "90", "80" }, 
                { "陳五", "20", "70" } };
            double chinese_score = Convert.ToDouble(textBox1.Text);
            double english_score = Convert.ToDouble(textBox2.Text);
            textBox3.Text = "姓名  國文 英文\r\n";
            int student_chinese, student_english;
            for(int i = 0;i<student.GetLength(0);i++)
            {
                student_chinese = Convert.ToInt32(student[i, 1]);
                student_english = Convert.ToInt32(student[i, 2]);

                if (student_chinese >= chinese_score && student_english>=english_score)
                    textBox3.Text += string.Format("{0}  {1}     {2} \r\n", student[i, 0], student[i, 1], student[i, 2]);
                
            }
        }
    }
}
