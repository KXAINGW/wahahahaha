﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace s1101327_Assignment2_1
{
    class Program
    {
        static void Main(string[] args)
        {
            double[,] price = { { 0, 140, 480, 950 }, { 130, 0, 550, 880 }, { 520, 430, 0, 520 }, { 980, 870, 500, 0 } };
            string[] station = { "台北", "桃園", "台中", "高雄" };

            Console.Write("最便宜票價為: ");
            double ticket_price = Convert.ToDouble(Console.ReadLine());
            int starting_point = 0, end_point = 0, b = 0;
            if (ticket_price != 0)
            {
                for (int i = 0; i < price.GetLength(0); i++)
                {
                    end_point = 0;
                    for (int i2 = 0; i2 < price.GetLength(1); i2++)
                    {
                        if (price[i, i2] == ticket_price)
                        {
                            b = 1;
                            break;
                        }
                        end_point++;

                    }
                    if (b == 1)
                        break;
                    starting_point++;
                }

                Console.WriteLine("起始站為: {0} \n終點站為: {1}", station[starting_point], station[end_point]);
            }
            else
                Console.Write("");

        }
    }
}
