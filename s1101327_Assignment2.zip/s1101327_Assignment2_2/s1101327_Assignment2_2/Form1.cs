﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace s1101327_Assignment2_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string[] station = { "台北", "桃園", "台中", "高雄" };
            for(int i = 0;i<station.Length;i++)
            {
                comboBox1.Items.Add(station[i]); //Add 方法：items屬性的方法之一
                comboBox2.Items.Add(station[i]);
            }
            //comboBox1.Text = station[0];  預選值
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double[,] price = { { 0, 140, 480, 950 }, { 130, 0, 550, 880 }, { 520, 430, 0, 520 }, { 980, 870, 500, 0 } };
            

            int starting_station = Convert.ToInt32(comboBox1.SelectedIndex);  //SelectedIndex 屬性返回一個表示與當前選定列表項的索引的整數值，可以程式設計更改它
            int end_station = Convert.ToInt32(comboBox2.SelectedIndex);
            label4.Text = Convert.ToString(price[starting_station, end_station]);
            //SelectedItem 屬性與 SelectedIndex 屬性類似，但是SelectedItem 屬性返回的是項
            //SelectedText 屬性：表示組合框中當前選定文字的字串
            //BeginUpdate 方法和 EndUpdate 方法：當使用Add 方法一次新增一個項時，則可以使用 BeginUpdate 方法，以防止每次向列表新增項時控制元件都重新繪製 ComboBox。完成向列表新增項的任務後，呼叫 EndUpdate 方法來啟用 ComboBox 進行重新繪製。當向列表新增大量的項時，使用這種方法新增項可以防止繪製 ComboBox 時閃爍
        }
    }
}
