﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace s1101327_Midterm_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string path = @"C:\Users\YZU\Desktop\nschool.txt";
            MyData student = new MyData();
            
            string[] name = student.GetDataColumn(path, 1);
            for (int i = 0; i < name.Length; i++)
                listBox1.Items.Add(name[i]);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string path2 = @"C:\Users\YZU\Desktop\naddress.txt";
            MyData student = new MyData();
            string[,] data2 = student.GetData(path2);
            string path3 = @"C:\Users\YZU\Desktop\nschool.txt";
            string[] name = student.GetDataColumn(path3, 1);


            string result = "";
            if(checkBox1.Checked == true)
            {
                string[] sex = student.GetDataColumn(path3, 2);
                for (int i = 0; i < name.Length; i++)
                {
                    string text = Convert.ToString(listBox1.SelectedItem);
                    if (text == name[i])
                        result += "性別: " + sex[i]+"\r\n";
                }     
            }
            if (checkBox2.Checked == true)
            {
                string[] department = student.GetDataColumn(path3, 3);
                for (int i = 0; i < name.Length; i++)
                {
                    string text = Convert.ToString(listBox1.SelectedItem);
                    if (text == name[i])
                        result += "系所: " + department[i] + "\r\n";
                }
            }
            if (checkBox3.Checked == true)
            {
                for (int i = 0; i < name.Length; i++)
                {
                    string text = Convert.ToString(listBox1.SelectedItem);
                    if (text == name[i])
                        result += "住址: " + data2[i+1,1] + "\r\n";
                }
            }
            if (checkBox4.Checked == true)
            {
                for (int i = 0; i < name.Length; i++)
                {
                    string text = Convert.ToString(listBox1.SelectedItem);
                    if (text == name[i])
                        result += "電話: " + data2[i + 1, 2] + "\r\n";
                }
            }
            MessageBox.Show(result);
        }
    }

    class MyData
    {
        public string[,] GetData(string path)
        {
            
            FileInfo fi = new FileInfo(path);
            StreamReader sr = fi.OpenText();
            int row = 57, column = 3;
            string[,] data = new string[row, column];
            string temp = "";
            int index = 0;
            while ((temp = sr.ReadLine()) != null)
            {
                for (int i = 0; i < column; i++)
                    data[index, i] = temp.Split(',')[i];
                index++;
            }
            sr.Close();
            return data;

        }
        public string[] GetDataColumn(string path, int column_number)
        {
            string[,] data = GetData(path);
            string[] name = new string[data.GetLength(0) - 1];
            for (int i = 1; i < data.GetLength(0); i++)
                name[i - 1] = data[i, column_number-1];
            return name;
        }

    }
}
