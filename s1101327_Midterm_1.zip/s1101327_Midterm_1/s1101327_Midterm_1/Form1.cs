﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace s1101327_Midterm_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        DataTable dt = new DataTable();
        private void Form1_Load(object sender, EventArgs e)
        {
            dt.Columns.Add("Name");
            dt.Columns.Add("Department");
            dt.Columns.Add("Mean");
            dt.Columns.Add("SD");
            dataGridView1.DataSource = dt;

            openFileDialog1.Filter = "All files(*.*)|*.*";
            openFileDialog1.InitialDirectory = "C:";
            openFileDialog1.FileName = "";
            openFileDialog1.Title = "開啟";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
                textBox1.Text = openFileDialog1.FileName;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string path = textBox1.Text;
            FileInfo fi = new FileInfo(path);
            StreamReader sr = fi.OpenText();
            int row = 57, column = 9;
            string[,] data = new string[row, column];
            string temp = "";
            int index = 0;
            while ((temp = sr.ReadLine()) != null)
            {
                for (int i = 0; i < column; i++)
                    data[index, i] = temp.Split(' ')[i];
                index++;
            }
            sr.Close();

            dt.Rows.Clear();
            for (int i = 1; i < row; i++)
            {
                double sum = 0, mean = 0, sd = 0, a = 0;
                for (int i2 = 2; i2 < column; i2++)
                {
                    sum += Convert.ToDouble(data[i, i2]);
                    a += Convert.ToDouble(data[i, i2]) * Convert.ToDouble(data[i, i2]);
                }
                mean = sum / 7;
                sd = Math.Sqrt(a / 7 - mean * mean);
                dt.Rows.Add(data[i, 0], data[i, 1], mean, sd);
            }

        }
    }
}
