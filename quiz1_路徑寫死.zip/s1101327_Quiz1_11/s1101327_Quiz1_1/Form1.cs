﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace s1101327_Quiz1_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            radioButton1.Checked = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "text files(*.txt)|.txt|All files(*.*)|*.*";
            openFileDialog1.InitialDirectory = "C:";
            openFileDialog1.FileName = "";
            openFileDialog1.Title = "開啟";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
                textBox1.Text = openFileDialog1.FileName;

        }


        private void button2_Click(object sender, EventArgs e)
        {
            string[,] data = Mymath.GetData(textBox1.Text);
            int row = 1259, column = 6;

            double[,] stocks = new double[row, column - 1];
            for (int i = 0; i < data.GetLength(0); i++)
            {
                for (int i2 = 1; i2 < data.GetLength(1); i2++)
                {
                    stocks[i, i2 - 1] = Convert.ToDouble(data[i, i2]);
                }
            }

            double[] stocks2 = new double[row];
            if(radioButton1.Checked == true)
            {
                for (int i = 0; i < row; i++)
                    stocks2[i] = stocks[i, 0];
                label7.Text = Convert.ToString(Mymath.Min(stocks2));
                label8.Text = Convert.ToString(Mymath.Max(stocks2));
                label9.Text = Convert.ToString(Mymath.Mean(stocks2));
                label10.Text = Convert.ToString(Mymath.SD(stocks2));
            }

            if (radioButton2.Checked == true)
            {
                for (int i = 0; i < row; i++)
                    stocks2[i] = stocks[i, 1];
                label7.Text = Convert.ToString(Mymath.Min(stocks2));
                label8.Text = Convert.ToString(Mymath.Max(stocks2));
                label9.Text = Convert.ToString(Mymath.Mean(stocks2));
                label10.Text = Convert.ToString(Mymath.SD(stocks2));
            }

            if (radioButton3.Checked == true)
            {
                for (int i = 0; i < row; i++)
                    stocks2[i] = stocks[i, 2];
                label7.Text = Convert.ToString(Mymath.Min(stocks2));
                label8.Text = Convert.ToString(Mymath.Max(stocks2));
                label9.Text = Convert.ToString(Mymath.Mean(stocks2));
                label10.Text = Convert.ToString(Mymath.SD(stocks2));
            }

            if (radioButton4.Checked == true)
            {
                for (int i = 0; i < row; i++)
                    stocks2[i] = stocks[i, 3];
                label7.Text = Convert.ToString(Mymath.Min(stocks2));
                label8.Text = Convert.ToString(Mymath.Max(stocks2));
                label9.Text = Convert.ToString(Mymath.Mean(stocks2));
                label10.Text = Convert.ToString(Mymath.SD(stocks2));
            }

            if (radioButton5.Checked == true)
            {
                for (int i = 0; i < row; i++)
                    stocks2[i] = stocks[i, 4];
                label7.Text = Convert.ToString(Mymath.Min(stocks2));
                label8.Text = Convert.ToString(Mymath.Max(stocks2));
                label9.Text = Convert.ToString(Mymath.Mean(stocks2));
                label10.Text = Convert.ToString(Mymath.SD(stocks2));
            }

        }
        class Mymath
        {
            
            public static string[,] GetData(string path)
            {
                FileInfo fi = new FileInfo(path);
                StreamReader sr = fi.OpenText();
                int row = 1259, column = 6;
                string[,] data = new string[row, column];
                string tt = "";
                int index = 0;
                while ((tt = sr.ReadLine()) != null)
                {
                    string[] temp2 = tt.Split(',');
                    for (int i = 0; i < temp2.Length; i++)
                        data[index, i] = temp2[i];
                    index++;
                }
                sr.Close();
                
                return data;


            }

            public static double Min(double[] data)
            {
                double min = data[0];
                for(int i = 0;i<data.Length;i++)
                {
                    if (min > data[i])
                        min = data[i];
                }
                return min;
            }

            public static double Max(double[] data)
            {
                double max = data[0];
                for (int i = 0; i < data.Length; i++)
                {
                    if (max < data[i])
                        max = data[i];
                }
                return max;

            }

            public static double Mean(double[] data)
            {
                double s = 0;
                for (int i = 0; i < data.Length; i++)
                    s += data[i];
                return s / data.Length;
            }

            public static double SD(double[] data)
            {
                double u = Mean(data);
                double a = 0;
                for (int i = 0; i < data.Length; i++)
                    a += data[i] * data[i];
                return Math.Sqrt(a / data.Length - u * u);
            }

        }

    }
}
