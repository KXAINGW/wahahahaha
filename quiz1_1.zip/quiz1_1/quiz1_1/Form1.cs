﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace quiz1_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
                textBox1.Text = openFileDialog1.FileName;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "text files(*.txt)|*.txt| All files(*.*)|*.*";
            openFileDialog1.InitialDirectory = "C:";
            openFileDialog1.FileName = "";
            openFileDialog1.Title = "開啟";
            radioButton1.Checked = true;
            

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if(radioButton1.Checked == true)
            {
                string[,] stocks = Mymath.a(textBox1.Text);

                string[] open = new string[stocks.GetLength(0)];
                for(int i = 0;i<stocks.GetLength(0);i++)
                    open[i] = stocks[i, 1];
                label6.Text = Convert.ToString(Mymath.Min(open));
                label7.Text = Convert.ToString(Mymath.Max(open));
                label8.Text = Convert.ToString(Mymath.Ave(open));
                label9.Text = Convert.ToString(Mymath.Standard_deviation(open));
        
            }

            if (radioButton2.Checked == true)
            {
                string[,] stocks = Mymath.a(textBox1.Text);

                string[] open = new string[stocks.GetLength(0)];
                for (int i = 0; i < stocks.GetLength(0); i++)
                    open[i] = stocks[i, 2];
                label6.Text = Convert.ToString(Mymath.Min(open));
                label7.Text = Convert.ToString(Mymath.Max(open));
                label8.Text = Convert.ToString(Mymath.Ave(open));
                label9.Text = Convert.ToString(Mymath.Standard_deviation(open));


            }

            if (radioButton3.Checked == true)
            {
                string[,] stocks = Mymath.a(textBox1.Text);

                string[] open = new string[stocks.GetLength(0)];
                for (int i = 0; i < stocks.GetLength(0); i++)
                    open[i] = stocks[i, 3];
                label6.Text = Convert.ToString(Mymath.Min(open));
                label7.Text = Convert.ToString(Mymath.Max(open));
                label8.Text = Convert.ToString(Mymath.Ave(open));
                label9.Text = Convert.ToString(Mymath.Standard_deviation(open));


            }

            if (radioButton4.Checked == true)
            {
                string[,] stocks = Mymath.a(textBox1.Text);

                string[] open = new string[stocks.GetLength(0)];
                for (int i = 0; i < stocks.GetLength(0); i++)
                    open[i] = stocks[i, 4];
                label6.Text = Convert.ToString(Mymath.Min(open));
                label7.Text = Convert.ToString(Mymath.Max(open));
                label8.Text = Convert.ToString(Mymath.Ave(open));
                label9.Text = Convert.ToString(Mymath.Standard_deviation(open));


            }

            if (radioButton5.Checked == true)
            {
                string[,] stocks = Mymath.a(textBox1.Text);

                string[] open = new string[stocks.GetLength(0)];
                for (int i = 0; i < stocks.GetLength(0); i++)
                    open[i] = stocks[i, 5];
                label6.Text = Convert.ToString(Mymath.Min(open));
                label7.Text = Convert.ToString(Mymath.Max(open));
                label8.Text = Convert.ToString(Mymath.Ave(open));
                label9.Text = Convert.ToString(Mymath.Standard_deviation(open));


            }

        }
    }
    class Mymath
    {
        public static string[,]a(string path)
        {
            FileInfo fi = new FileInfo(path);
            StreamReader sr = fi.OpenText();
            int row = 0, column = 0;
            string a;

            while ((a = sr.ReadLine()) != null)
            {
                string[] temp = a.Split(',');
                if (row == 0)
                {
                    column = temp.Length;

                }
                row++;
            }
            sr.Close();

            string[,] data = new string[row, column];
            string text;
            int index = 0;

            sr = fi.OpenText();
            while ((text = sr.ReadLine()) != null)
            {
                string[] temp2 = text.Split(',');
                for (int i = 0; i < column; i++)
                {
                    data[index, i] = temp2[i];
                }
                index++;
            }
            return data;
        }
        public static double Min(string[] value)
        {
            double min = Convert.ToDouble(value[0]);
            for (int i = 0; i < value.Length; i++)
            {
                double temp = Convert.ToDouble(value[i]);
                if (min >= temp)
                    min = temp;

            }
            return min;
        }

        public static double Max(string[] value)
        {
            double max = Convert.ToDouble(value[0]);
            for (int i = 0; i < value.Length; i++)
            {
                double temp = Convert.ToDouble(value[i]);
                if (max <= temp)
                    max = temp;

            }
            return max;
        }
        public static double Ave(string[] value)
        {
            double ave = 0;
            for (int i = 0; i < value.Length; i++)
            {
                double temp = Convert.ToDouble(value[i]);
                ave += temp;

            }
            return ave/value.Length;
        }
        public static double Standard_deviation(string[] value)
        {
            double ave = Ave(value);
            double st = 0;
            for (int i = 0; i < value.Length; i++)
            {
                double temp = Convert.ToDouble(value[i]);
                st += Math.Pow((temp - ave), 2);


            }
            double st_final = Math.Sqrt(st / value.Length);
            return st_final;
        }



    }

}
