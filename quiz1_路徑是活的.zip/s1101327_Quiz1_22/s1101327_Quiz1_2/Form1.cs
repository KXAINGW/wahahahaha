﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace s1101327_Quiz1_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            textBox1.Text = "0";
            textBox2.Text = "0";
            textBox3.Text = "0";
            textBox4.Text = "0";

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string path = @"C:\Users\ASUS\OneDrive\桌面\yzu\程設\iem.txt";
            FileInfo fi = new FileInfo(path);
            StreamReader sr = fi.OpenText();

            /*
            int row = 0, column = 0;
            string text = "";
            while ((text = sr.ReadLine()) != null)
            {
                if (row == 0)
                {
                    string[] temp = text.Split(' ');
                    column = temp.Length;
                }
                row++;
            }
            */

            int row = 57, column = 6;
            string[,] data = new string[row, column];
            string tt = "";
            int index = 0;
            while ((tt = sr.ReadLine()) != null)
            {
                string[] temp2 = tt.Split(' ');
                for (int i = 0; i < temp2.Length; i++)
                    data[index, i] = temp2[i];
                index++;
            }
            
            sr.Close();
            textBox5.Text = " 姓名 國文 數學 英文 統計\r\n";

            int chinese = Convert.ToInt32(textBox1.Text);
            int english = Convert.ToInt32(textBox2.Text);
            int math = Convert.ToInt32(textBox3.Text);
            int aa = Convert.ToInt32(textBox4.Text);
            for(int i = 1;i<row;i++)
            {
                int mychinese = Convert.ToInt32(data[i, 2]);
                int myenglish = Convert.ToInt32(data[i, 3]);
                int mymath = Convert.ToInt32(data[i, 4]);
                int myaa = Convert.ToInt32(data[i, 5]);

                if (mychinese >= chinese && myenglish >= english && mymath >= math && myaa >= aa  )
                {
                    textBox5.Text += string.Format("{0}  {1}  {2}  {3}  {4}\r\n", data[i, 0], data[i, 2], data[i, 3], data[i, 4], data[i, 5]);

                }
            }




        }

        private void button2_Click(object sender, EventArgs e)
        {
            string path = @"C:\Users\ASUS\OneDrive\桌面\yzu\程設\iem.txt";
            FileInfo fi = new FileInfo(path);
            StreamReader sr = fi.OpenText();

            /*
            int row = 0, column = 0;
            string text = "";
            while ((text = sr.ReadLine()) != null)
            {
                if (row == 0)
                {
                    string[] temp = text.Split(' ');
                    column = temp.Length;
                }
                row++;
            }
            */

            int row = 57, column = 6;
            string[,] data = new string[row, column];
            string tt = "";
            int index = 0;
            while ((tt = sr.ReadLine()) != null)
            {
                string[] temp2 = tt.Split(' ');
                for (int i = 0; i < temp2.Length; i++)
                    data[index, i] = temp2[i];
                index++;
            }

            sr.Close();
            textBox5.Text = " 姓名 系所\r\n";

            int chinese = Convert.ToInt32(textBox1.Text);
            int english = Convert.ToInt32(textBox2.Text);
            int math = Convert.ToInt32(textBox3.Text);
            int aa = Convert.ToInt32(textBox4.Text);
            for (int i = 1; i < row; i++)
            {
                int mychinese = Convert.ToInt32(data[i, 2]);
                int myenglish = Convert.ToInt32(data[i, 3]);
                int mymath = Convert.ToInt32(data[i, 4]);
                int myaa = Convert.ToInt32(data[i, 5]);

                if (mychinese >= chinese && myenglish >= english && mymath >= math && myaa >= aa)
                {
                    textBox5.Text += string.Format("{0}  {1}\r\n", data[i, 0], data[i, 1]);

                }
            }


        }
    }
}
